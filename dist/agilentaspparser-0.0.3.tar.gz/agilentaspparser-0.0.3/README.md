# Agilent IR spectrum file parsers



In our lab we have an Agilent Cary 660 ATR-IR spectrometer. The ASCII files produced by this device are a nuissance to work with beacause they don't feature a wavenumber column. This 'library' intends to make work with said files a bit easier by parsing spectra and adding missing information.
